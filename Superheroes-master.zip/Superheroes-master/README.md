# Superheroes
<li> A simple UI using recycler view showing 20 characters at once and a refresh button which refreshes the entry of superhero data.
<li> Used Java For Android
<li> Used Volley Library for acessing Api and Picasso for image insertion.

# Demo Images 
<div>
<img src="https://user-images.githubusercontent.com/87039911/199420753-85c2d13e-8de4-48ec-8cd7-4b2d6b9e3ce9.jpg" height="500px" width="245px">
<img src="https://user-images.githubusercontent.com/87039911/199422834-ba207035-5f97-4bba-9a57-8ea28f7c90ea.jpg" height="500px" width="245px">
<img src="https://user-images.githubusercontent.com/87039911/199421134-4ed11c77-3598-438b-9393-5b85899a27f6.jpg" height="500px" width="245px">
<img src="https://user-images.githubusercontent.com/87039911/199421329-218f46a3-9956-432c-b3d1-9738991b4938.jpg" height="500px" width="245px">
</div>

# Demo Video
https://user-images.githubusercontent.com/87039911/199424619-ad16efe5-61bb-41bb-8bc2-c71101c01a4f.mp4
